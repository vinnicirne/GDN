
export default function ContactView() {
  return null;
}
